<footer>
  &copy; 2025 Fashion Luxy. Todos los derechos reservados.
</footer>