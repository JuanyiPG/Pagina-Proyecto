<nav class="nav-admin">
    <a href="/Admin/index-admin.html"><img src="../IMG/logo rosa.jpeg" alt="Logo"></a>
    <ul>
        <li class="menu-v-t"><a href="../Admin/index-admin.php">Dashboard</a></li>
        <li class="menu-v-t"><a href="#">Usuarios</a></li>
        <li class="menu-v-t"><a href="../Formularios/producto.php">Productos</a></li>
        <li class="menu-v-t"><a href="#">Ventas</a></li>
        <li class="menu-v-t"><a href="#">Ajustes</a></li>
        <li class="menu-v-t"><a href="../Pagina_principal/pagina_principal TechSLY.php">Cerrar sesión</a></li>
    </ul>
</nav>