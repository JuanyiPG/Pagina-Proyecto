<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/index.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <title>Productos Luxy Fashion</title>
    <style>
        body{
            display: flex;
            height: 100vh;
        }
    </style>
</head>
<body>
    <header id="header"></header>
    <br>
    <main style="margin-left: 25%;">
         <div class="title-prod">
             <h1>Productos</h1>
         </div>
        <div class="Buscador">
            <i class="bi bi-search"></i>
            <input type="search" placeholder="Buscar..">
        </div>
        <br>
      <section class="seccion">
        <h2 class="titulo-seccion">Chaquetas</h2>
        <div class="contenedor-productos">
          <div class="producto">
            <img src="../IMG/Chaquet_de_cuero_hombre.jpeg" alt="Chaqueta cuero">
            <p>Chaqueta Black Panther</p>
          </div>
          <div class="producto">
            <img src="../IMG/chaqueta_clasica.jpeg" alt="Chaqueta clásica">
            <p>Chaqueta Clásica</p>
          </div>
          <div class="producto">
            <img src="../IMG/Chaqueta_moderna.jpeg" alt="Chaqueta moderna">
            <p>Chaqueta Moderna</p>
          </div>
        </div>
        <a href="#" class="ver-mas">Ver más productos</a>
      </section>
      <br>
      <section class="seccion">
        <h2 class="titulo-seccion">Pantalones</h2>
        <div class="contenedor-productos">
          <div class="producto">
            <img src="../IMG/cargo.jpeg" alt="Chaqueta cuero">
            <p>Chaqueta Black Panther</p>
          </div>
          <div class="producto">
            <img src="../IMG/Campana.jpeg" alt="Chaqueta clásica">
            <p>Chaqueta Clásica</p>
          </div>
          <div class="producto">
            <img src="../IMG/Baggy.jpeg" alt="Chaqueta moderna">
            <p>Chaqueta Moderna</p>
          </div>
        </div>
        <a href="#" class="ver-mas">Ver más productos</a>
      </section>
      <button class="ver-mas-final">Ver más</button>
      <hr>
      <br>
  </main>
</body>
<script>
    fetch('../Admin/header-admin.php').then(res => res.text()) 
    .then(data => { document.getElementById("header").innerHTML = data; }); 
</script>
</html>