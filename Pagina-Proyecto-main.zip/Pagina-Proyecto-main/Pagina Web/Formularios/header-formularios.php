<div class="nav">
    <ul>
      <li class="m-left" id="list"><i class="bi bi-house-door-fill" onclick="window.history.back()"></i>
      <a href="/Admin/index-admin.html"><img src="/IMG/logo rosa.jpeg" alt="Logo"></a>
      </li>
    </ul>
  </div>
  