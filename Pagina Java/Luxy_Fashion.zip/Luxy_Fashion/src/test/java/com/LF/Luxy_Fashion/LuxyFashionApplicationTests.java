package com.LF.Luxy_Fashion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LuxyFashionApplicationTests {

	@Test
	void contextLoads() {
	}

}
